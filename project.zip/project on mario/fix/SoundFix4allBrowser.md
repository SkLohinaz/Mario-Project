***$vP3R MAr10 bR0$ S0vND F1X***

<img src="https://i.imgur.com/SAPU3LH.gif" 
alt="Mario is Alive!" width="600" height="450" border="100" />

The original code uses audio files contained in the sounds folder as a source, which works well on Opera, Chrome and Safari, while with Internet Explorer and Mozilla the audio does not start in autoplay, but I could not fix it with the html5 tag.
I had tried to embed directly youtube videos and then hide them with the tag hidden = "true", but since the audio files I used are the originals, and therefore protected by copyright, they were blocked directly by youtube, thus causing the failure audio autoplay; (
But I managed to find a nice remix with a creative commons license of Super Mario Bros, this time it obviously worked and the audio part in autoplay on all the browsers except for safari.
But i really hate apple so I do not give a fuck ...




Find the file indexwithsoundfix.html, and replace the index.html with this; you're done ...

</br>
<img src="https://i.imgur.com/SAPU3LH.gif" 
alt="Mario is Alive!" width="600" height="450" border="100" />


 Song : Mario 
 
 Artist : JJD
 
 https://www.youtube.com/channel/UCYaIvjDg3TMnsqc6wbaEhIQ
 

 
 <img src="https://i.imgur.com/SAPU3LH.gif" 
alt="Mario is Alive!" width="600" height="450" border="100" />




you can try a demo here:
</br>
https://codepen.io/JonnyBanana/pen/paQyKo
</br>
<a href="https://codepen.io/JonnyBanana/pen/paQyKo
" target="_blank"><img src="https://i.imgur.com/z7PMR46.jpg" 
alt="Mario is Alive!" width="600" height="450" border="100" /></a> 


<img src="https://i.imgur.com/SAPU3LH.gif" 
alt="Mario is Alive!" width="600" height="450" border="100" />
